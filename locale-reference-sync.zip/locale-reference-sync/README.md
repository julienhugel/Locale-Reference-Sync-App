# Locale Reference Sync — Contentful App

A Contentful [App Framework](https://www.contentful.com/developers/docs/extensibility/app-framework/)
app that removes the biggest manual chore of running a many-locale landing
page: **re-listing the same references in every locale.**

Editors curate the reference fields once in the **default locale**, then use
this app to **duplicate those references to any (or all) other locales** in one
click, and — because module libraries are often drafted on a staging
environment — to **bulk-publish the referenced entries** afterwards.

Built for the **Yves Saint Laurent** campaign workflow; deliberately generic and
safe, so it can be reused across **Kering** maisons without touching anything
else.

- **Target space**: `ovwrfri4z4es` (environment `main`).
- **Locations**: `Entry sidebar` (the panel), `Dialog` (the pop-up), `App configuration`.
- **Stack**: Vite + React + TypeScript, `@contentful/app-sdk`, `@contentful/react-apps-toolkit`, Forma 36.

---

## What it does (and what it will never do)

**Does**

- Auto-detects the **localized Entry-reference fields** on the content type
  (`Link → Entry` and `Array<Link → Entry>` with *localized* on). You can also
  pin an explicit list of field ids in the config screen.
- **Duplicate references from default → locales**: a pop-up lists every locale
  with a status badge (`empty` / `in sync` / `customised`). Pick individual
  locales or *Select all*, choose whether to overwrite already-filled locales,
  and confirm. Only empty locales are filled unless *overwrite* is enabled.
- **Publish referenced entries**: a pop-up lists every entry referenced across
  all locales with its draft/published state; confirm to bulk-publish them
  (batched, with a small retry on version conflicts).

**Never**

- Touches any field other than the tracked reference fields.
- Edits, unpublishes, archives or deletes any entry it wasn't asked to publish.
- Clears a locale: if the default locale is empty for a field, that field is
  skipped (never used to wipe other locales).
- Runs anything automatically — every write is behind an explicit button + dialog.

Duplication is written through the **editor's own field API**, so changes appear
live in the entry editor and autosave normally (no version conflicts with the
open entry). Publishing uses the CMA against the *referenced* entries only.

---

## The content model (demo)

Created by `scripts/create-model.mjs`:

- **`campaign`** — a landing page. `heroModule` (`Link`) and `modules`
  (`Array<Link>`) are **localized** — these are what the app syncs.
- **`campaignModule`** — a reusable, localizable module (`hero`, `editorial`,
  `productGrid`, `video`, `lookbook`, `newsletter`).

`scripts/create-locales.mjs` adds ~30 optional, `en-US`-fallback market locales,
and `scripts/seed-demo.mjs` seeds a *Libre Eau de Parfum* campaign whose
references exist only in the default locale (the pain the app removes).

---

## Local development

```bash
npm install
npm run dev   # http://localhost:3001
```

Point the app definition's bundle URL at `http://localhost:3001` while
developing.

## Deployment

### 1. Create the App Definition

```bash
npm run create-app-definition
```

In the wizard: choose the organisation, name it **Locale Reference Sync**, and
enable the **App configuration**, **Entry sidebar** and **Dialog** locations.
Leave “Hosted by Contentful”. This writes the `APP_DEFINITION_ID` into `.env`.

### 2. Build & upload the bundle

```bash
npm run deploy   # = npm run build && npm run upload
```

### 3. Install & add to a content type

Install the app on `ovwrfri4z4es` / `main`, then either:

- **Manually**: open the `campaign` content type → **Sidebar** tab → add
  “Locale Reference Sync”. *(The panel only appears where you add it.)*
- **Scripted**:
  ```bash
  CONTENTFUL_ACCESS_TOKEN=... CONTENTFUL_APP_DEF_ID=... \
  CONTENTFUL_TARGET_CT=campaign node scripts/install-widget.mjs
  ```

### CI / non-interactive upload

```bash
CONTENTFUL_ORG_ID=... CONTENTFUL_APP_DEF_ID=... CONTENTFUL_ACCESS_TOKEN=... \
npm run upload-ci
```

---

## Sharing with another team / organization (e.g. Kering maisons)

On Contentful an **App Definition belongs to a single organization** and is
installable on **every space of that org**, but not from another org. There is
no private cross-org share, so there are two transparent, reproducible paths.
The full source lives in this repo — nothing is hidden or hard-coded to one
space (the app auto-detects fields at runtime; scripts read space/env/org from
env vars).

### Case A — Same organization (other spaces / maisons)

Nothing to redeploy. Reuse the existing App Definition id and:

```bash
# 1. Install the app on their space/environment
CONTENTFUL_ACCESS_TOKEN=<token> \
CONTENTFUL_SPACE_ID=<their-space> CONTENTFUL_ENV_ID=main \
CONTENTFUL_APP_DEF_ID=<existing-app-def-id> \
npm run install-app

# 2. Add the sidebar widget to the relevant content type(s)
CONTENTFUL_ACCESS_TOKEN=<token> \
CONTENTFUL_SPACE_ID=<their-space> CONTENTFUL_ENV_ID=main \
CONTENTFUL_APP_DEF_ID=<existing-app-def-id> \
CONTENTFUL_TARGET_CT=<their-content-type> \
npm run install-widget
```

Or install from the UI: `Apps → Manage apps → Locale Reference Sync → Install`,
then add the widget under the content type’s **Sidebar** tab.

### Case B — Different organization (deploy an isolated copy)

Clone this repo and deploy the **same code** into their org. Each org keeps its
own bundle, app definition, installations and data — fully isolated.

```bash
git clone <repo-url> && cd locale-reference-sync && npm install

# 1. Create THEIR app definition (enable app-config, entry-sidebar, dialog)
CONTENTFUL_ACCESS_TOKEN=<their-token> CONTENTFUL_ORG_ID=<their-org> \
  npm run create-app-definition

# 2. Build, upload and activate the bundle in their org
CONTENTFUL_ACCESS_TOKEN=<their-token> CONTENTFUL_ORG_ID=<their-org> \
  npm run deploy

# 3. Install + widget (as in Case A, using THEIR app definition id)
CONTENTFUL_ACCESS_TOKEN=<their-token> CONTENTFUL_SPACE_ID=<their-space> \
CONTENTFUL_ENV_ID=main CONTENTFUL_APP_DEF_ID=<their-app-def-id> \
  npm run install-app
```

No code changes are required — only their identifiers. The reference model,
locales and demo data can also be recreated in their space with `npm run model`
/ `npm run locales` / `npm run seed` if they want the same starting point.

> "Hosted by Contentful" means the bundle lives in the org that defines it, so
> another org cannot point at it — hence the re-upload in Case B.

### Case C — Broad distribution (Marketplace / Developer Showcase)

The only *official* cross-org channel is listing on the
[Contentful Marketplace](https://ctfl.io/submit-app) or
[Developer Showcase](https://ctfl.io/dev-showcase). Note the listing is
**public** — use only if you intend open distribution.

## Configuration options (App configuration screen)

| Option | Default | Purpose |
| --- | --- | --- |
| **Reference fields** | *(auto)* | CSV allow-list of field ids to sync. Empty = auto-detect localized Entry references. |
| **Overwrite by default** | off | Pre-checks the overwrite toggle in the dialog. |
| **Enable “Publish referenced entries”** | on | Show/hide the bulk-publish button. |

## Reproduce the demo from scratch

```bash
export CONTENTFUL_ACCESS_TOKEN=<CMA token>   # + optional SPACE_ID / ENV_ID
npm run model      # content types
npm run locales    # ~30 market locales
npm run seed       # demo campaign + modules
```

## Project layout

```
src/
  App.tsx                 # routes App SDK locations
  config.ts               # installation params + dialog contracts
  lib/references.ts       # pure, SDK-free reference logic
  locations/
    ConfigScreen.tsx       # App configuration
    Sidebar.tsx            # status summary + the two actions (executor)
    Dialog.tsx             # locale picker + publish confirmation (pop-up)
scripts/
  _client.mjs             # tiny CMA client (reads space/env/token from env)
  create-model.mjs        # content types (campaign + campaignModule)
  create-locales.mjs      # ~30 optional, en-US-fallback market locales
  seed-demo.mjs           # demo campaign + module drafts
  install-app.mjs         # install/update the app on a space/env
  install-widget.mjs      # add the sidebar widget to a content type
```

## Transparency & safety

- No secrets are committed: `.env` is git-ignored; only `.env.example` (with
  non-secret demo defaults) is tracked.
- No space is hard-coded in the app — it reads everything from the App SDK at
  runtime; the scripts read `CONTENTFUL_SPACE_ID` / `CONTENTFUL_ENV_ID` /
  `CONTENTFUL_ACCESS_TOKEN` / `CONTENTFUL_ORG_ID` / `CONTENTFUL_APP_DEF_ID`.
- The reference logic is isolated in `src/lib/references.ts` (framework-free),
  so it is easy to audit and reuse.
