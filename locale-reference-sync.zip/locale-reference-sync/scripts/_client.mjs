/**
 * Tiny CMA client shared by the scripts. Reads config from the environment:
 *   CONTENTFUL_ACCESS_TOKEN (required)  — a CMA token
 *   CONTENTFUL_SPACE_ID     (default ovwrfri4z4es)
 *   CONTENTFUL_ENV_ID       (default main)
 */

export const SPACE = process.env.CONTENTFUL_SPACE_ID || 'ovwrfri4z4es';
export const ENV = process.env.CONTENTFUL_ENV_ID || 'main';
const TOKEN = process.env.CONTENTFUL_ACCESS_TOKEN;

if (!TOKEN) {
  console.error('Missing CONTENTFUL_ACCESS_TOKEN env var.');
  process.exit(1);
}

const BASE = `https://api.contentful.com/spaces/${SPACE}/environments/${ENV}`;
const HEADERS = {
  Authorization: `Bearer ${TOKEN}`,
  'Content-Type': 'application/vnd.contentful.management.v1+json',
};

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function api(path, options = {}, version) {
  const headers = { ...HEADERS, ...(options.headers || {}) };
  if (version !== undefined) headers['X-Contentful-Version'] = String(version);
  let res;
  for (let attempt = 0; attempt < 6; attempt++) {
    res = await fetch(`${BASE}${path}`, { ...options, headers });
    if (res.status !== 429) break;
    await sleep(1000 * (attempt + 1));
  }
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const err = new Error(
      `${res.status} ${options.method || 'GET'} ${path} :: ${JSON.stringify(
        body?.details || body?.message || body
      )}`
    );
    err.status = res.status;
    throw err;
  }
  return body;
}
