/**
 * Adds the Locale Reference Sync widget to a content type's entry sidebar,
 * preserving every existing sidebar widget. Idempotent and non-destructive.
 *
 * Usage:
 *   CONTENTFUL_ACCESS_TOKEN=<CMA token> \
 *   CONTENTFUL_APP_DEF_ID=<app definition id> \
 *   CONTENTFUL_TARGET_CT=campaign \
 *   node scripts/install-widget.mjs
 */

import { api } from './_client.mjs';

const APP_DEF_ID = process.env.CONTENTFUL_APP_DEF_ID;
const TARGET_CT = process.env.CONTENTFUL_TARGET_CT || 'campaign';

if (!APP_DEF_ID) {
  console.error('Missing CONTENTFUL_APP_DEF_ID env var.');
  process.exit(1);
}

const DEFAULT_SIDEBAR = [
  'publication-widget',
  'releases-widget',
  'content-preview-widget',
  'incoming-links-widget',
  'translation-widget',
  'versions-widget',
  'users-widget',
].map((widgetId) => ({ widgetId, widgetNamespace: 'sidebar-builtin', settings: {} }));

async function main() {
  const ei = await api(`/content_types/${TARGET_CT}/editor_interface`);
  const current = Array.isArray(ei.sidebar) ? ei.sidebar : DEFAULT_SIDEBAR;

  if (current.some((w) => w.widgetNamespace === 'app' && w.widgetId === APP_DEF_ID)) {
    console.log(`Widget already present on "${TARGET_CT}". Nothing to do.`);
    return;
  }

  const sidebar = [
    { widgetId: APP_DEF_ID, widgetNamespace: 'app', settings: {} },
    ...current,
  ];

  const payload = { sidebar };
  if (ei.controls) payload.controls = ei.controls;
  if (ei.groupControls) payload.groupControls = ei.groupControls;
  if (ei.editors) payload.editors = ei.editors;
  if (ei.editorLayout) payload.editorLayout = ei.editorLayout;

  await api(
    `/content_types/${TARGET_CT}/editor_interface`,
    { method: 'PUT', body: JSON.stringify(payload) },
    ei.sys.version
  );
  console.log(`Added Locale Reference Sync to the "${TARGET_CT}" sidebar.`);
}

main().catch((e) => {
  console.error('FAILED:', e.message);
  process.exit(1);
});
