/**
 * Adds a realistic global-market locale set (so the "30+ locales" pain is
 * tangible). All locales are OPTIONAL and fall back to en-US, so nothing
 * becomes required or breaks existing content. Existing locales are skipped.
 *
 * Usage: CONTENTFUL_ACCESS_TOKEN=<CMA token> node scripts/create-locales.mjs
 */

import { api, sleep } from './_client.mjs';

const FALLBACK = 'en-US';

// Curated set of markets. en-US already exists as the default locale.
const LOCALES = [
  ['en-GB', 'English (United Kingdom)'],
  ['en-AU', 'English (Australia)'],
  ['fr', 'French'],
  ['fr-CA', 'French (Canada)'],
  ['de-DE', 'German (Germany)'],
  ['it', 'Italian'],
  ['es-ES', 'Spanish (Spain)'],
  ['es-MX', 'Spanish (Mexico)'],
  ['pt-BR', 'Portuguese (Brazil)'],
  ['pt-PT', 'Portuguese (Portugal)'],
  ['nl-NL', 'Dutch (Netherlands)'],
  ['sv-SE', 'Swedish (Sweden)'],
  ['da-DK', 'Danish (Denmark)'],
  ['nb-NO', 'Norwegian Bokmål (Norway)'],
  ['fi-FI', 'Finnish (Finland)'],
  ['pl-PL', 'Polish (Poland)'],
  ['cs-CZ', 'Czech (Czechia)'],
  ['el-GR', 'Greek (Greece)'],
  ['tr-TR', 'Turkish (Turkey)'],
  ['ru-RU', 'Russian (Russia)'],
  ['ar-AE', 'Arabic (United Arab Emirates)'],
  ['ar-SA', 'Arabic (Saudi Arabia)'],
  ['ja-JP', 'Japanese (Japan)'],
  ['ko-KR', 'Korean (South Korea)'],
  ['zh-CN', 'Chinese (Mainland)'],
  ['zh-TW', 'Chinese (Taiwan)'],
  ['zh-HK', 'Chinese (Hong Kong)'],
  ['th-TH', 'Thai (Thailand)'],
  ['vi-VN', 'Vietnamese (Vietnam)'],
  ['id-ID', 'Indonesian (Indonesia)'],
  ['ms-MY', 'Malay (Malaysia)'],
];

async function main() {
  const existing = new Set((await api('/locales?limit=100')).items.map((l) => l.code));
  let created = 0;
  for (const [code, name] of LOCALES) {
    if (existing.has(code)) {
      console.log(`  = ${code} (exists)`);
      continue;
    }
    await api('/locales', {
      method: 'POST',
      body: JSON.stringify({
        code,
        name,
        fallbackCode: code === FALLBACK ? null : FALLBACK,
        optional: true,
        contentDeliveryApi: true,
        contentManagementApi: true,
      }),
    });
    created++;
    console.log(`  + ${code}`);
    await sleep(150);
  }
  console.log(`\nDone. Created ${created} locale(s).`);
}

main().catch((e) => {
  console.error('FAILED:', e.message);
  process.exit(1);
});
