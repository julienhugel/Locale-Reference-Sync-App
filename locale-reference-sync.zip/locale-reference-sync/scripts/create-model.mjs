/**
 * Creates & publishes the Campaign content model used by the Locale Reference
 * Sync demo:
 *   - campaignModule : a reusable, localizable content module
 *   - campaign       : a landing page whose `heroModule` and `modules`
 *                      reference fields are LOCALIZED (the whole point of the app)
 *
 * Usage: CONTENTFUL_ACCESS_TOKEN=<CMA token> node scripts/create-model.mjs
 */

import { api, sleep } from './_client.mjs';

const sym = (id, name, extra = {}) => ({ id, name, type: 'Symbol', localized: false, required: false, validations: [], disabled: false, omitted: false, ...extra });
const text = (id, name, extra = {}) => ({ id, name, type: 'Text', localized: false, required: false, validations: [], disabled: false, omitted: false, ...extra });
const date = (id, name, extra = {}) => ({ id, name, type: 'Date', localized: false, required: false, validations: [], disabled: false, omitted: false, ...extra });
const assetLink = (id, name, extra = {}) => ({ id, name, type: 'Link', linkType: 'Asset', localized: false, required: false, validations: [], disabled: false, omitted: false, ...extra });
const entryLink = (id, name, ct, extra = {}) => ({ id, name, type: 'Link', linkType: 'Entry', localized: false, required: false, validations: [{ linkContentType: [ct] }], disabled: false, omitted: false, ...extra });
const entryLinkArray = (id, name, ct, extra = {}) => ({ id, name, type: 'Array', localized: false, required: false, validations: [], disabled: false, omitted: false, items: { type: 'Link', linkType: 'Entry', validations: [{ linkContentType: [ct] }] }, ...extra });

const MODEL = [
  {
    id: 'campaignModule',
    name: 'Campaign Module',
    displayField: 'internalName',
    description:
      'A reusable content module (hero, editorial, product grid, video, …) referenced by Campaign landing pages.',
    fields: [
      sym('internalName', 'Internal name', { required: true }),
      sym('moduleType', 'Module type', { required: true, validations: [{ in: ['hero', 'editorial', 'productGrid', 'video', 'lookbook', 'newsletter'] }] }),
      sym('eyebrow', 'Eyebrow', { localized: true }),
      sym('heading', 'Heading', { localized: true }),
      text('body', 'Body', { localized: true }),
      assetLink('media', 'Media', { localized: true }),
      sym('ctaLabel', 'CTA label', { localized: true }),
      sym('ctaUrl', 'CTA URL'),
    ],
  },
  {
    id: 'campaign',
    name: 'Campaign',
    displayField: 'internalName',
    description:
      'A campaign landing page. The module list is LOCALIZED: curate it once in the default locale, then use Locale Reference Sync to duplicate the references to every market.',
    fields: [
      sym('internalName', 'Internal name', { required: true }),
      sym('title', 'Title', { required: true, localized: true }),
      sym('slug', 'Slug', { localized: true }),
      sym('campaignStatus', 'Status', { validations: [{ in: ['draft', 'scheduled', 'live', 'archived'] }] }),
      date('launchDate', 'Launch date'),
      entryLink('heroModule', 'Hero module', 'campaignModule', { localized: true }),
      entryLinkArray('modules', 'Modules', 'campaignModule', { localized: true }),
      sym('seoTitle', 'SEO title', { localized: true }),
      text('seoDescription', 'SEO description', { localized: true }),
    ],
  },
];

async function upsert(ct) {
  let version;
  try {
    const existing = await api(`/content_types/${ct.id}`);
    version = existing.sys.version;
  } catch {
    version = undefined;
  }
  const payload = { name: ct.name, displayField: ct.displayField, description: ct.description, fields: ct.fields };
  const saved = await api(`/content_types/${ct.id}`, { method: 'PUT', body: JSON.stringify(payload) }, version);
  return saved.sys.version;
}

async function publish(id) {
  const ct = await api(`/content_types/${id}`);
  await api(`/content_types/${id}/published`, { method: 'PUT' }, ct.sys.version);
}

async function main() {
  console.log('Creating content types…');
  for (const ct of MODEL) {
    await upsert(ct);
    console.log(`  · ${ct.id}`);
    await sleep(120);
  }
  console.log('Publishing…');
  for (const ct of MODEL) {
    await publish(ct.id);
    console.log(`  · ${ct.id}`);
    await sleep(120);
  }
  console.log('\nDone:', MODEL.map((m) => m.id).join(', '));
}

main().catch((e) => {
  console.error('FAILED:', e.message);
  process.exit(1);
});
