/**
 * Installs (or updates) the app on a space/environment in one command.
 * Works both for the same organization (Case A) and for a freshly redeployed
 * copy in another organization (Case B) — you just point it at the right
 * space, environment and app definition id.
 *
 * Usage:
 *   CONTENTFUL_ACCESS_TOKEN=<CMA token> \
 *   CONTENTFUL_SPACE_ID=<space> \
 *   CONTENTFUL_ENV_ID=main \
 *   CONTENTFUL_APP_DEF_ID=<app definition id> \
 *   node scripts/install-app.mjs
 *
 * Optional installation parameters (all have safe defaults):
 *   APP_REFERENCE_FIELD_IDS   comma-separated field ids (default: auto-detect)
 *   APP_DEFAULT_OVERWRITE     "true" | "false"  (default: false)
 *   APP_ENABLE_PUBLISH        "true" | "false"  (default: true)
 */

import { api, SPACE, ENV } from './_client.mjs';

const APP_DEF_ID = process.env.CONTENTFUL_APP_DEF_ID;
if (!APP_DEF_ID) {
  console.error('Missing CONTENTFUL_APP_DEF_ID env var.');
  process.exit(1);
}

const parameters = {
  referenceFieldIds: process.env.APP_REFERENCE_FIELD_IDS ?? '',
  defaultOverwrite: process.env.APP_DEFAULT_OVERWRITE === 'true',
  enablePublish: process.env.APP_ENABLE_PUBLISH !== 'false',
};

async function main() {
  const res = await api(
    `/app_installations/${APP_DEF_ID}`,
    {
      method: 'PUT',
      headers: {
        'X-Contentful-Marketplace':
          'i-accept-marketplace-terms-of-service',
      },
      body: JSON.stringify({ parameters }),
    }
  );
  if (res?.sys?.type === 'AppInstallation') {
    console.log(
      `Installed "${APP_DEF_ID}" on ${SPACE}/${ENV} with parameters:`,
      JSON.stringify(parameters)
    );
  } else {
    console.log(JSON.stringify(res, null, 2));
  }
}

main().catch((e) => {
  console.error('FAILED:', e.message);
  process.exit(1);
});
