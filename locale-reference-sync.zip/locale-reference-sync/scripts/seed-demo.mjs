/**
 * Seeds a demo Yves Saint Laurent campaign:
 *   - 5 campaignModule drafts (left UNPUBLISHED so the "Publish" button has work)
 *   - 1 campaign entry populated ONLY in the default locale (all other locales
 *     are intentionally empty — the manual pain the app removes)
 *
 * Usage: CONTENTFUL_ACCESS_TOKEN=<CMA token> node scripts/seed-demo.mjs
 */

import { api, sleep } from './_client.mjs';

async function defaultLocale() {
  const locales = await api('/locales?limit=100');
  return (locales.items.find((l) => l.default) || locales.items[0]).code;
}

async function createEntry(contentTypeId, fields) {
  const entry = await api('/entries', {
    method: 'POST',
    headers: { 'X-Contentful-Content-Type': contentTypeId },
    body: JSON.stringify({ fields }),
  });
  return entry.sys.id;
}

const link = (id) => ({ sys: { type: 'Link', linkType: 'Entry', id } });

async function main() {
  const L = await defaultLocale();
  const one = (v) => ({ [L]: v });

  console.log(`Seeding in default locale "${L}"…`);

  const modules = [
    { internalName: 'Libre — Hero', moduleType: 'hero', eyebrow: 'New Fragrance', heading: 'Libre — The Scent of Freedom', body: "The freedom to burn with desire. Yves Saint Laurent's iconic floral fragrance.", ctaLabel: 'Discover Libre', ctaUrl: '/fragrance/libre' },
    { internalName: 'Libre — Editorial Story', moduleType: 'editorial', eyebrow: 'The Story', heading: 'A Fragrance Born of Tension', body: 'Orange blossom from Morocco meets lavender essence from France.', ctaLabel: 'Read the story', ctaUrl: '/fragrance/libre/story' },
    { internalName: 'Libre — Product Grid', moduleType: 'productGrid', eyebrow: 'The Collection', heading: 'Discover the Libre Collection', body: 'Eau de Parfum, Intense, and the refillable 90ml edition.', ctaLabel: 'Shop the collection', ctaUrl: '/fragrance/libre/products' },
    { internalName: 'Libre — Campaign Film', moduleType: 'video', eyebrow: 'The Film', heading: 'Dua Lipa for Libre', body: 'Watch the new campaign film.', ctaLabel: 'Watch the film', ctaUrl: '/fragrance/libre/film' },
    { internalName: 'YSL — Newsletter Signup', moduleType: 'newsletter', eyebrow: 'Stay in touch', heading: 'Join the House of Yves Saint Laurent', body: 'Be the first to know about new launches and exclusive events.', ctaLabel: 'Sign up', ctaUrl: '/account/newsletter' },
  ];

  const ids = [];
  for (const m of modules) {
    const id = await createEntry('campaignModule', {
      internalName: one(m.internalName),
      moduleType: one(m.moduleType),
      eyebrow: one(m.eyebrow),
      heading: one(m.heading),
      body: one(m.body),
      ctaLabel: one(m.ctaLabel),
      ctaUrl: one(m.ctaUrl),
    });
    ids.push(id);
    console.log(`  + module ${m.internalName} (${id})`);
    await sleep(120);
  }

  const [hero, ...rest] = ids;
  const campaignId = await createEntry('campaign', {
    internalName: one('YSL — Libre Eau de Parfum Launch'),
    title: one('Libre Eau de Parfum'),
    slug: one('libre-eau-de-parfum'),
    campaignStatus: one('draft'),
    launchDate: one('2026-10-01'),
    heroModule: one(link(hero)),
    modules: one(rest.map(link)),
    seoTitle: one('Libre Eau de Parfum | Yves Saint Laurent'),
    seoDescription: one('Discover Libre, the new floral fragrance by Yves Saint Laurent.'),
  });
  console.log(`  + campaign (${campaignId})`);

  console.log('\nDone. Modules are drafts; the campaign has references only in the default locale.');
}

main().catch((e) => {
  console.error('FAILED:', e.message);
  process.exit(1);
});
