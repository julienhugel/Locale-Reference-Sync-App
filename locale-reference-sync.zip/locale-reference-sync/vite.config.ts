import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Contentful hosts the app bundle from a relative base, and expects the
// production build in the `build` directory.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    outDir: 'build',
  },
  server: {
    port: 3001,
  },
});
