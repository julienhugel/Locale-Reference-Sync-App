import { useEffect, useMemo, useState } from 'react';
import { useSDK } from '@contentful/react-apps-toolkit';
import type { DialogAppSDK } from '@contentful/app-sdk';
import {
  Badge,
  Box,
  Button,
  Checkbox,
  Flex,
  Note,
  Paragraph,
  Stack,
  Text,
} from '@contentful/f36-components';
import {
  DialogInvocation,
  LocaleRow,
  LocaleSyncStatus,
  PublishRow,
} from '../config';

const STATUS_BADGE: Record<
  LocaleSyncStatus,
  { label: string; variant: 'positive' | 'warning' | 'secondary' }
> = {
  inSync: { label: 'in sync', variant: 'positive' },
  empty: { label: 'empty', variant: 'warning' },
  customised: { label: 'customised', variant: 'secondary' },
};

const listBoxStyle: React.CSSProperties = {
  maxHeight: 340,
  overflowY: 'auto',
  border: '1px solid #e7ebee',
  borderRadius: 6,
  padding: 12,
};

const Dialog = () => {
  const sdk = useSDK<DialogAppSDK>();
  const invocation = sdk.parameters.invocation as unknown as DialogInvocation;

  useEffect(() => {
    sdk.window.startAutoResizer();
    return () => sdk.window.stopAutoResizer();
  }, [sdk.window]);

  if (!invocation || !('mode' in invocation)) {
    return (
      <Box padding="spacingL">
        <Note variant="negative">The dialog was opened without parameters.</Note>
      </Box>
    );
  }

  return invocation.mode === 'duplicate' ? (
    <DuplicatePanel sdk={sdk} invocation={invocation} />
  ) : (
    <PublishPanel sdk={sdk} entries={invocation.entries} />
  );
};

function DuplicatePanel({
  sdk,
  invocation,
}: {
  sdk: DialogAppSDK;
  invocation: Extract<DialogInvocation, { mode: 'duplicate' }>;
}) {
  const { locales, defaultLocaleName, fieldNames, defaultOverwrite } = invocation;

  const [overwrite, setOverwrite] = useState<boolean>(defaultOverwrite);
  // Safe default: pre-select only the locales that are still empty.
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(locales.filter((l) => l.status === 'empty').map((l) => l.code))
  );

  const toggle = (code: string, checked: boolean) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(code);
      else next.delete(code);
      return next;
    });

  const allSelected = selected.size === locales.length && locales.length > 0;
  const someSelected = selected.size > 0 && !allSelected;

  const setAll = (checked: boolean) =>
    setSelected(checked ? new Set(locales.map((l) => l.code)) : new Set());

  const selectByStatus = (status: LocaleSyncStatus) =>
    setSelected(new Set(locales.filter((l) => l.status === status).map((l) => l.code)));

  return (
    <Box padding="spacingL">
      <Stack flexDirection="column" alignItems="stretch" spacing="spacingM">
        <Paragraph marginBottom="none">
          Copy{' '}
          {fieldNames.map((n, i) => (
            <span key={n}>
              {i > 0 ? ', ' : ''}
              <code>{n}</code>
            </span>
          ))}{' '}
          from <strong>{defaultLocaleName}</strong> into the selected locales.
        </Paragraph>

        <Flex justifyContent="space-between" alignItems="center" flexWrap="wrap" gap="spacingXs">
          <Checkbox
            isChecked={allSelected}
            isIndeterminate={someSelected}
            onChange={(e) => setAll(e.target.checked)}
          >
            Select all ({selected.size}/{locales.length})
          </Checkbox>
          <Flex gap="spacingXs">
            <Button size="small" variant="transparent" onClick={() => selectByStatus('empty')}>
              Only empty
            </Button>
            <Button size="small" variant="transparent" onClick={() => setAll(false)}>
              Clear
            </Button>
          </Flex>
        </Flex>

        <Box style={listBoxStyle}>
          <Stack flexDirection="column" alignItems="stretch" spacing="spacingXs">
            {locales.map((row: LocaleRow) => (
              <Flex key={row.code} justifyContent="space-between" alignItems="center">
                <Checkbox
                  isChecked={selected.has(row.code)}
                  onChange={(e) => toggle(row.code, e.target.checked)}
                >
                  {row.name}{' '}
                  <Text fontColor="gray500" as="span">
                    ({row.code})
                  </Text>
                </Checkbox>
                <Badge variant={STATUS_BADGE[row.status].variant}>
                  {STATUS_BADGE[row.status].label}
                </Badge>
              </Flex>
            ))}
          </Stack>
        </Box>

        <Checkbox isChecked={overwrite} onChange={(e) => setOverwrite(e.target.checked)}>
          Overwrite locales that already have references
        </Checkbox>
        {!overwrite && (
          <Text fontColor="gray500" fontSize="fontSizeS">
            With overwrite off, locales marked “customised” or “in sync” keep
            their current references — only empty locales are filled.
          </Text>
        )}

        <Flex justifyContent="flex-end" gap="spacingS">
          <Button variant="secondary" onClick={() => sdk.close(undefined)}>
            Cancel
          </Button>
          <Button
            variant="primary"
            isDisabled={selected.size === 0}
            onClick={() =>
              sdk.close({
                action: 'duplicate',
                locales: [...selected],
                overwrite,
              })
            }
          >
            Duplicate to {selected.size} locale{selected.size === 1 ? '' : 's'}
          </Button>
        </Flex>
      </Stack>
    </Box>
  );
}

function PublishPanel({ sdk, entries }: { sdk: DialogAppSDK; entries: PublishRow[] }) {
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(entries.map((e) => e.id))
  );

  const toggle = (id: string, checked: boolean) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });

  const allSelected = selected.size === entries.length && entries.length > 0;
  const someSelected = selected.size > 0 && !allSelected;
  const setAll = (checked: boolean) =>
    setSelected(checked ? new Set(entries.map((e) => e.id)) : new Set());

  const draftCount = useMemo(
    () => entries.filter((e) => !e.published).length,
    [entries]
  );

  return (
    <Box padding="spacingL">
      <Stack flexDirection="column" alignItems="stretch" spacing="spacingM">
        <Paragraph marginBottom="none">
          {entries.length} entr{entries.length === 1 ? 'y is' : 'ies are'} referenced
          across all locales{draftCount > 0 ? ` (${draftCount} not yet published)` : ''}.
          Publishing sends them to the current environment.
        </Paragraph>

        <Checkbox
          isChecked={allSelected}
          isIndeterminate={someSelected}
          onChange={(e) => setAll(e.target.checked)}
        >
          Select all ({selected.size}/{entries.length})
        </Checkbox>

        <Box style={listBoxStyle}>
          <Stack flexDirection="column" alignItems="stretch" spacing="spacingXs">
            {entries.map((row) => (
              <Flex key={row.id} justifyContent="space-between" alignItems="center">
                <Checkbox
                  isChecked={selected.has(row.id)}
                  onChange={(e) => toggle(row.id, e.target.checked)}
                >
                  {row.label}{' '}
                  <Text fontColor="gray500" as="span">
                    ({row.kind})
                  </Text>
                </Checkbox>
                <Badge variant={row.published ? 'positive' : 'warning'}>
                  {row.published ? 'published' : 'draft'}
                </Badge>
              </Flex>
            ))}
          </Stack>
        </Box>

        <Flex justifyContent="flex-end" gap="spacingS">
          <Button variant="secondary" onClick={() => sdk.close(undefined)}>
            Cancel
          </Button>
          <Button
            variant="positive"
            isDisabled={selected.size === 0}
            onClick={() =>
              sdk.close({ action: 'publish', entryIds: [...selected] })
            }
          >
            Publish {selected.size} entr{selected.size === 1 ? 'y' : 'ies'}
          </Button>
        </Flex>
      </Stack>
    </Box>
  );
}

export default Dialog;
