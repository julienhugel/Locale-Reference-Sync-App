import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSDK } from '@contentful/react-apps-toolkit';
import type { SidebarAppSDK, SerializedJSONValue } from '@contentful/app-sdk';
import {
  Badge,
  Box,
  Button,
  Flex,
  Note,
  Paragraph,
  Spinner,
  Stack,
  Text,
} from '@contentful/f36-components';
import {
  AppInstallationParameters,
  DEFAULT_PARAMETERS,
  DialogInvocation,
  DialogResult,
  LocaleRow,
  parseFieldIds,
  PublishRow,
} from '../config';
import {
  chunk,
  cloneValue,
  collectReferencedIds,
  detectReferenceFields,
  GetValue,
  isEmptyValue,
  localeStatus,
  RefFieldDef,
} from '../lib/references';

interface Progress {
  label: string;
  done: number;
  total: number;
}

const Sidebar = () => {
  const sdk = useSDK<SidebarAppSDK>();

  const params = {
    ...DEFAULT_PARAMETERS,
    ...(sdk.parameters.installation as AppInstallationParameters),
  };
  const overrideIds = parseFieldIds(params.referenceFieldIds);
  const enablePublish = params.enablePublish !== false;

  const defaultLocale = sdk.locales.default;
  const localeNames = sdk.locales.names;
  const nonDefaultLocales = useMemo(
    () => sdk.locales.available.filter((code) => code !== defaultLocale),
    [sdk.locales.available, defaultLocale]
  );

  const refFields: RefFieldDef[] = useMemo(
    () => detectReferenceFields(sdk.contentType.fields, overrideIds),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sdk.contentType.fields, params.referenceFieldIds]
  );

  const getValue: GetValue = useCallback(
    (fieldId, locale) => sdk.entry.fields[fieldId]?.getValue(locale),
    [sdk.entry.fields]
  );

  const [rows, setRows] = useState<LocaleRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<Progress | null>(null);

  const refreshStatus = useCallback(() => {
    if (refFields.length === 0) {
      setRows([]);
      return;
    }
    setRows(
      nonDefaultLocales.map((code) => ({
        code,
        name: localeNames[code] ?? code,
        status: localeStatus(refFields, getValue, defaultLocale, code),
      }))
    );
  }, [refFields, nonDefaultLocales, localeNames, getValue, defaultLocale]);

  useEffect(() => {
    sdk.window.startAutoResizer();
    return () => sdk.window.stopAutoResizer();
  }, [sdk.window]);

  // Recompute whenever the entry is saved (covers our own writes and native edits).
  useEffect(() => {
    refreshStatus();
    const detach = sdk.entry.onSysChanged(() => refreshStatus());
    return () => detach();
  }, [sdk.entry, refreshStatus]);

  const stats = useMemo(() => {
    const empty = rows.filter((r) => r.status === 'empty').length;
    const inSync = rows.filter((r) => r.status === 'inSync').length;
    const customised = rows.filter((r) => r.status === 'customised').length;
    return { empty, inSync, customised, total: rows.length };
  }, [rows]);

  const defaultHasContent = useMemo(
    () => refFields.some((f) => !isEmptyValue(getValue(f.id, defaultLocale))),
    [refFields, getValue, defaultLocale]
  );

  /** Copy the default-locale value of each tracked field into the chosen locales. */
  const runDuplicate = useCallback(
    async (targetLocales: string[], overwrite: boolean) => {
      setBusy(true);
      let fieldsWritten = 0;
      let skipped = 0;
      try {
        const total = targetLocales.length;
        for (let i = 0; i < total; i++) {
          const locale = targetLocales[i];
          setProgress({
            label: `Copying to ${localeNames[locale] ?? locale}`,
            done: i,
            total,
          });
          for (const field of refFields) {
            const entryField = sdk.entry.fields[field.id];
            if (!entryField) continue;
            const defaultValue = entryField.getValue(defaultLocale);
            if (isEmptyValue(defaultValue)) continue; // never clear a locale
            const localeValue = entryField.getValue(locale);
            if (!overwrite && !isEmptyValue(localeValue)) {
              skipped++;
              continue;
            }
            await entryField.setValue(cloneValue(defaultValue), locale);
            fieldsWritten++;
          }
        }
        setProgress({ label: 'Done', done: total, total });
        sdk.notifier.success(
          `Duplicated references to ${total} locale${total === 1 ? '' : 's'} ` +
            `(${fieldsWritten} field value${fieldsWritten === 1 ? '' : 's'} written` +
            `${skipped ? `, ${skipped} left untouched` : ''}).`
        );
      } catch (err) {
        sdk.notifier.error(
          `Duplication failed: ${err instanceof Error ? err.message : 'unknown error'}`
        );
      } finally {
        setBusy(false);
        setProgress(null);
        refreshStatus();
      }
    },
    [refFields, sdk.entry.fields, sdk.notifier, defaultLocale, localeNames, refreshStatus]
  );

  /** Publish each referenced entry (batched, with a small retry on conflicts). */
  const runPublish = useCallback(
    async (entryIds: string[]) => {
      setBusy(true);
      let published = 0;
      const failures: string[] = [];
      try {
        const batches = chunk(entryIds, 5);
        let done = 0;
        for (const batch of batches) {
          await Promise.all(
            batch.map(async (entryId) => {
              for (let attempt = 0; attempt < 4; attempt++) {
                try {
                  const entry = await sdk.cma.entry.get({ entryId });
                  await sdk.cma.entry.publish({ entryId }, entry);
                  published++;
                  return;
                } catch (err) {
                  const status =
                    (err as { status?: number })?.status ??
                    (err as { code?: number })?.code;
                  const retriable = status === 409 || status === 429;
                  if (!retriable || attempt === 3) {
                    failures.push(entryId);
                    return;
                  }
                  await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
                }
              }
            })
          );
          done += batch.length;
          setProgress({ label: 'Publishing entries', done, total: entryIds.length });
        }
        if (failures.length === 0) {
          sdk.notifier.success(
            `Published ${published} referenced entr${published === 1 ? 'y' : 'ies'}.`
          );
        } else {
          sdk.notifier.warning(
            `Published ${published}, but ${failures.length} could not be published ` +
              `(they may have validation errors). Open them to review.`
          );
        }
      } catch (err) {
        sdk.notifier.error(
          `Publish failed: ${err instanceof Error ? err.message : 'unknown error'}`
        );
      } finally {
        setBusy(false);
        setProgress(null);
      }
    },
    [sdk.cma, sdk.notifier]
  );

  const onOpenDuplicate = useCallback(async () => {
    const invocation: DialogInvocation = {
      mode: 'duplicate',
      defaultLocale,
      defaultLocaleName: localeNames[defaultLocale] ?? defaultLocale,
      fieldNames: refFields.map((f) => f.name),
      locales: rows,
      defaultOverwrite: !!params.defaultOverwrite,
    };
    const result = (await sdk.dialogs.openCurrentApp({
      title: 'Duplicate references from default',
      width: 'large',
      minHeight: 420,
      shouldCloseOnOverlayClick: true,
      shouldCloseOnEscapePress: true,
      parameters: invocation as unknown as SerializedJSONValue,
    })) as DialogResult;

    if (result?.action === 'duplicate' && result.locales.length > 0) {
      await runDuplicate(result.locales, result.overwrite);
    }
  }, [
    defaultLocale,
    localeNames,
    refFields,
    rows,
    params.defaultOverwrite,
    sdk.dialogs,
    runDuplicate,
  ]);

  const onOpenPublish = useCallback(async () => {
    setBusy(true);
    try {
      const ids = collectReferencedIds(refFields, getValue, sdk.locales.available);
      if (ids.length === 0) {
        sdk.notifier.warning('There are no referenced entries to publish yet.');
        return;
      }
      const res = await sdk.cma.entry.getMany({
        query: { 'sys.id[in]': ids.join(','), limit: 1000 },
      });
      const entries: PublishRow[] = res.items.map((entry) => {
        const fields = entry.fields ?? {};
        const label =
          (fields.internalName?.[defaultLocale] as string) ??
          (fields.title?.[defaultLocale] as string) ??
          (fields.name?.[defaultLocale] as string) ??
          entry.sys.id;
        const kind =
          (fields.moduleType?.[defaultLocale] as string) ??
          entry.sys.contentType?.sys.id ??
          'entry';
        return {
          id: entry.sys.id,
          label,
          kind,
          published: Boolean(entry.sys.publishedVersion),
        };
      });

      const invocation: DialogInvocation = { mode: 'publish', entries };
      const result = (await sdk.dialogs.openCurrentApp({
        title: 'Publish referenced entries',
        width: 'large',
        minHeight: 420,
        shouldCloseOnOverlayClick: true,
        shouldCloseOnEscapePress: true,
        parameters: invocation as unknown as SerializedJSONValue,
      })) as DialogResult;

      if (result?.action === 'publish' && result.entryIds.length > 0) {
        await runPublish(result.entryIds);
      }
    } catch (err) {
      sdk.notifier.error(
        `Could not load referenced entries: ${
          err instanceof Error ? err.message : 'unknown error'
        }`
      );
    } finally {
      setBusy(false);
    }
  }, [refFields, getValue, sdk.locales.available, sdk.cma, sdk.notifier, sdk.dialogs, defaultLocale, runPublish]);

  if (refFields.length === 0) {
    return (
      <Note variant="warning" title="No localized reference fields">
        This content type has no localized Entry-reference field, so there is
        nothing to sync. Mark a reference (or list of references) field as
        <em> localized</em>, or set the field ids in the app configuration.
      </Note>
    );
  }

  return (
    <Stack flexDirection="column" alignItems="stretch" spacing="spacingS">
      <Box>
        <Text fontColor="gray500" fontSize="fontSizeS">
          Tracking{' '}
          {refFields.map((f, i) => (
            <span key={f.id}>
              {i > 0 ? ', ' : ''}
              <code>{f.name}</code>
            </span>
          ))}{' '}
          across {nonDefaultLocales.length} locales.
        </Text>
      </Box>

      <Flex gap="spacingXs" flexWrap="wrap">
        <Badge variant="positive">{stats.inSync} in sync</Badge>
        <Badge variant="warning">{stats.empty} empty</Badge>
        <Badge variant="secondary">{stats.customised} customised</Badge>
      </Flex>

      {!defaultHasContent && (
        <Note variant="neutral">
          The default locale ({localeNames[defaultLocale] ?? defaultLocale}) has
          no references yet. Add them first, then duplicate.
        </Note>
      )}

      {progress && (
        <Flex alignItems="center" gap="spacingXs">
          <Spinner size="small" />
          <Text fontSize="fontSizeS">
            {progress.label} ({progress.done}/{progress.total})
          </Text>
        </Flex>
      )}

      <Button
        variant="primary"
        isFullWidth
        isDisabled={busy || !defaultHasContent}
        onClick={onOpenDuplicate}
      >
        Duplicate references from default…
      </Button>

      {enablePublish && (
        <Button
          variant="secondary"
          isFullWidth
          isDisabled={busy}
          onClick={onOpenPublish}
        >
          Publish referenced entries…
        </Button>
      )}

      <Paragraph marginBottom="none">
        <Text fontColor="gray500" fontSize="fontSizeS">
          Only the tracked reference fields are written. Nothing is ever
          unpublished or deleted.
        </Text>
      </Paragraph>
    </Stack>
  );
};

export default Sidebar;
