import { useCallback, useEffect, useState } from 'react';
import { useSDK } from '@contentful/react-apps-toolkit';
import type { ConfigAppSDK } from '@contentful/app-sdk';
import {
  Checkbox,
  Flex,
  Form,
  FormControl,
  Heading,
  Note,
  Paragraph,
  TextInput,
} from '@contentful/f36-components';
import { AppInstallationParameters, DEFAULT_PARAMETERS } from '../config';

const ConfigScreen = () => {
  const sdk = useSDK<ConfigAppSDK>();
  const [parameters, setParameters] =
    useState<AppInstallationParameters>(DEFAULT_PARAMETERS);

  const onConfigure = useCallback(async () => {
    const currentState = await sdk.app.getCurrentState();
    return { parameters, targetState: currentState };
  }, [parameters, sdk]);

  useEffect(() => {
    sdk.app.onConfigure(() => onConfigure());
  }, [sdk, onConfigure]);

  useEffect(() => {
    (async () => {
      const current =
        (await sdk.app.getParameters()) as AppInstallationParameters | null;
      if (current) {
        setParameters({ ...DEFAULT_PARAMETERS, ...current });
      }
      sdk.app.setReady();
    })();
  }, [sdk]);

  return (
    <Flex
      flexDirection="column"
      gap="spacingM"
      style={{ maxWidth: 720, margin: '80px auto', padding: '0 24px' }}
    >
      <Heading>Locale Reference Sync — Configuration</Heading>
      <Paragraph>
        Adds a sidebar panel that duplicates the <strong>localized reference
        fields</strong> of an entry from the default locale to any (or all)
        other locales, then optionally publishes the referenced entries. It only
        ever writes the tracked reference fields and never unpublishes or
        deletes anything.
      </Paragraph>

      <Form>
        <FormControl>
          <FormControl.Label>Reference fields (optional)</FormControl.Label>
          <TextInput
            value={parameters.referenceFieldIds ?? ''}
            onChange={(e) =>
              setParameters((p) => ({ ...p, referenceFieldIds: e.target.value }))
            }
            placeholder="modules, heroModule"
          />
          <FormControl.HelpText>
            Comma-separated field ids to sync. Leave empty to auto-detect every
            localized Entry-reference field on the content type.
          </FormControl.HelpText>
        </FormControl>

        <FormControl>
          <Checkbox
            isChecked={!!parameters.defaultOverwrite}
            onChange={(e) =>
              setParameters((p) => ({ ...p, defaultOverwrite: e.target.checked }))
            }
          >
            Overwrite by default
          </Checkbox>
          <FormControl.HelpText>
            Pre-checks the “overwrite locales that already have references”
            toggle in the dialog. When off (recommended), locales that editors
            have already customised are left untouched unless they opt in.
          </FormControl.HelpText>
        </FormControl>

        <FormControl>
          <Checkbox
            isChecked={parameters.enablePublish !== false}
            onChange={(e) =>
              setParameters((p) => ({ ...p, enablePublish: e.target.checked }))
            }
          >
            Enable “Publish referenced entries”
          </Checkbox>
          <FormControl.HelpText>
            Adds a button to bulk-publish every entry referenced by the tracked
            fields (useful on a staging environment).
          </FormControl.HelpText>
        </FormControl>
      </Form>

      <Note variant="neutral" title="Where to add it">
        After installing, open each content type that needs it, go to the
        <strong> Sidebar</strong> tab and add the “Locale Reference Sync” widget.
        The panel only appears where you add it, so it cannot affect other models.
      </Note>
    </Flex>
  );
};

export default ConfigScreen;
