/**
 * Locale Reference Sync — shared configuration and dialog contracts.
 *
 * The app has three jobs, and nothing else:
 *   1. Detect the *localized reference fields* on the current entry
 *      (Link -> Entry, or Array<Link -> Entry> with `localized: true`).
 *   2. Duplicate the default-locale value of those fields into the locales the
 *      editor selects (default is the single source of truth).
 *   3. Bulk-publish the entries referenced by those fields (handy on a staging
 *      environment where modules are drafted before go-live).
 *
 * It never edits any other field, never touches other entries beyond the ones
 * referenced, and never unpublishes or deletes anything.
 */

/** Installation-level parameters, edited on the App configuration screen. */
export interface AppInstallationParameters {
  /**
   * Optional comma-separated allow-list of field ids to sync. When empty the
   * app auto-detects every localized Entry-reference field on the content type.
   */
  referenceFieldIds?: string;
  /** Default state of the "overwrite locales that already have references" toggle. */
  defaultOverwrite?: boolean;
  /** Whether the "Publish referenced entries" action is available. Default true. */
  enablePublish?: boolean;
}

export const DEFAULT_PARAMETERS: Required<AppInstallationParameters> = {
  referenceFieldIds: '',
  defaultOverwrite: false,
  enablePublish: true,
};

/** How a target locale compares to the default locale for the tracked fields. */
export type LocaleSyncStatus =
  | 'empty' // no references at all in this locale
  | 'inSync' // identical to the default locale
  | 'customised'; // has references, but different from the default locale

export interface LocaleRow {
  code: string;
  name: string;
  status: LocaleSyncStatus;
}

export interface PublishRow {
  id: string;
  label: string;
  /** Content type id or moduleType, purely for display. */
  kind: string;
  published: boolean;
}

/** Parameters passed into the dialog location via `openCurrentApp`. */
export type DialogInvocation =
  | {
      mode: 'duplicate';
      defaultLocale: string;
      defaultLocaleName: string;
      fieldNames: string[];
      locales: LocaleRow[];
      defaultOverwrite: boolean;
    }
  | {
      mode: 'publish';
      entries: PublishRow[];
    };

/** Values the dialog returns to the sidebar via `sdk.close`. */
export type DuplicateResult = {
  action: 'duplicate';
  locales: string[];
  overwrite: boolean;
};

export type PublishResult = {
  action: 'publish';
  entryIds: string[];
};

export type DialogResult = DuplicateResult | PublishResult | undefined;

export function parseFieldIds(csv: string | undefined): string[] {
  return (csv ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}
