/**
 * Pure, SDK-agnostic helpers for working with (localized) Entry-reference
 * fields. Keeping this logic free of the App SDK makes the behaviour easy to
 * reason about and safe to unit test.
 */

import type { LocaleSyncStatus } from '../config';

/** A Contentful link to an entry. */
export interface EntryLink {
  sys: { type: 'Link'; linkType: 'Entry'; id: string };
}

/** Minimal shape of a content-type field definition (subset of the SDK type). */
export interface FieldDefLike {
  id: string;
  name: string;
  type: string;
  localized?: boolean;
  linkType?: string;
  items?: { type?: string; linkType?: string };
}

export type RefFieldKind = 'link' | 'linkArray';

export interface RefFieldDef {
  id: string;
  name: string;
  kind: RefFieldKind;
}

const isEntryLinkField = (f: FieldDefLike): boolean =>
  f.type === 'Link' && f.linkType === 'Entry';

const isEntryLinkArrayField = (f: FieldDefLike): boolean =>
  f.type === 'Array' && f.items?.type === 'Link' && f.items?.linkType === 'Entry';

/**
 * Detect the localized Entry-reference fields we are allowed to sync.
 * When `overrideIds` is non-empty, only those ids are considered (and they must
 * still be localized reference fields — anything else is ignored, for safety).
 */
export function detectReferenceFields(
  fields: FieldDefLike[],
  overrideIds: string[] = []
): RefFieldDef[] {
  const allow = new Set(overrideIds);
  return fields
    .filter((f) => f.localized === true)
    .filter((f) => isEntryLinkField(f) || isEntryLinkArrayField(f))
    .filter((f) => (allow.size === 0 ? true : allow.has(f.id)))
    .map((f) => ({
      id: f.id,
      name: f.name,
      kind: isEntryLinkArrayField(f) ? 'linkArray' : 'link',
    }));
}

export const isEmptyValue = (value: unknown): boolean =>
  value == null || (Array.isArray(value) && value.length === 0);

/** Deep clone a field value so locales never share a reference object. */
export function cloneValue<T>(value: T): T {
  if (value == null) return value;
  return JSON.parse(JSON.stringify(value)) as T;
}

/** Extract the ordered list of linked entry ids from a link or link-array value. */
export function linkIds(value: unknown): string[] {
  if (isEmptyValue(value)) return [];
  const arr = Array.isArray(value) ? value : [value];
  return arr
    .map((link) => (link as EntryLink | undefined)?.sys?.id)
    .filter((id): id is string => Boolean(id));
}

/**
 * Two reference values are "the same" when they link to the same ids in the
 * same order. (Order matters for module lists on a landing page.)
 */
export function sameReferences(a: unknown, b: unknown): boolean {
  const ida = linkIds(a);
  const idb = linkIds(b);
  return ida.length === idb.length && ida.every((id, i) => id === idb[i]);
}

/** Read a field value for a specific locale. */
export type GetValue = (fieldId: string, locale: string) => unknown;

/**
 * Compare a single target locale against the default locale across all tracked
 * fields and classify it.
 */
export function localeStatus(
  refFields: RefFieldDef[],
  getValue: GetValue,
  defaultLocale: string,
  locale: string
): LocaleSyncStatus {
  let hasAny = false;
  let allInSync = true;

  for (const field of refFields) {
    const defaultValue = getValue(field.id, defaultLocale);
    const localeValue = getValue(field.id, locale);
    if (!isEmptyValue(localeValue)) hasAny = true;
    if (!sameReferences(defaultValue, localeValue)) allInSync = false;
  }

  if (!hasAny) return 'empty';
  return allInSync ? 'inSync' : 'customised';
}

/** Collect every referenced entry id across the given locales and fields. */
export function collectReferencedIds(
  refFields: RefFieldDef[],
  getValue: GetValue,
  locales: string[]
): string[] {
  const ids = new Set<string>();
  for (const field of refFields) {
    for (const locale of locales) {
      for (const id of linkIds(getValue(field.id, locale))) ids.add(id);
    }
  }
  return [...ids];
}

/** Split an array into fixed-size chunks (used to batch publish calls). */
export function chunk<T>(items: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}
