import { useMemo } from 'react';
import { useSDK } from '@contentful/react-apps-toolkit';
import { locations } from '@contentful/app-sdk';
import Sidebar from './locations/Sidebar';
import ConfigScreen from './locations/ConfigScreen';
import Dialog from './locations/Dialog';

const App = () => {
  const sdk = useSDK();

  const Component = useMemo(() => {
    if (sdk.location.is(locations.LOCATION_APP_CONFIG)) {
      return ConfigScreen;
    }
    if (sdk.location.is(locations.LOCATION_ENTRY_SIDEBAR)) {
      return Sidebar;
    }
    if (sdk.location.is(locations.LOCATION_DIALOG)) {
      return Dialog;
    }
    return null;
  }, [sdk.location]);

  return Component ? <Component /> : null;
};

export default App;
